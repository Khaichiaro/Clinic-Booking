import "./Login.css";
import { Link, useNavigate } from "react-router-dom";
import Logo1 from "../../../assets/Logo1.png";
import { useState } from "react";
import { loginUser } from "../../../services/authService";

export default function LoginPage() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.type]: e.target.value });
  };

  const handleLogin = async () => {
    try {
      await loginUser(formData);
      navigate('/home');
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="container">
      <div className="card">
        <img src={Logo1} alt="logo" className="logo" />
        <h1>Booking Clinic</h1>
        <input type="email" placeholder="Email" value={formData.email} onChange={handleChange} />
        <input type="password" placeholder="Password" value={formData.password} onChange={handleChange} />
        <button className="btn" onClick={handleLogin}>Login</button>
        {error && <p style={{ color: "red" }}>{error}</p>}
        <p>
          Already have an account? <Link to="/register">Register</Link>
        </p>
      </div>
    </div>
  );
}
