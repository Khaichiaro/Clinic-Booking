// src/pages/HomePage.tsx
import './Home.css';
import { useNavigate } from 'react-router-dom';
import Logo1 from '../../../assets/Logo1.png';

export default function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="home-container">
      <header className="home-header">
        <img src={Logo1} className="logo" />
        <button className="logout-btn" onClick={() => navigate('/')}>Logout</button>
      </header>

      <main className="card-grid">
        <div className="card light" onClick={() => navigate('/patient')}>
          Your info
        </div>
        <div className="card purple" onClick={() => navigate('/appointments')}>
          Appointments
        </div>
        <div className="card dark" onClick={() => navigate('/doctors')}>
          Doctor
        </div>
      </main>
    </div>
  );
}
