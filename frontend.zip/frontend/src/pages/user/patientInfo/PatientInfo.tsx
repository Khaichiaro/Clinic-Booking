import './PatientInfo.css';
import { Link } from 'react-router-dom';
import PatientLogo from '../../../assets/PatientLogo.svg';

export default function PatientInfoPage() {
  return (
    <div className="info-container">
      <header>
        <img src="/stethoscope-icon.svg" />
        <button className="logout">Logout</button>
      </header>
      <div className="info-card">
        <img className="avatar" src={PatientLogo} />
        <h2>Pongsakorn In-on</h2>
        <div className="detail">
          <label>Password</label>
          <p>**********************</p>
        </div>
        <div className="detail">
          <label>Email</label>
          <p>pongsakorn.inon@gmail.com</p>
        </div>
        <div className="detail">
          <label>Phone</label>
          <p>063-442-5230</p>
        </div>
        <div className="detail">
          <label>Gender</label>
          <p>Male</p>
        </div>
        <Link to="/edit">
          <button className="btn">Edit</button>
        </Link>
      </div>
    </div>
  );
}
