import './Register.css';
import { Link } from 'react-router-dom';
import Logo1 from '../../../assets/Logo1.png';

export default function RegisterPage() {
  return (
    <div className="container">
      <div className="card">
        <img src={Logo1} className="logo" />
        <h2>Register</h2>
        <div className="row">
          <input placeholder="First name" />
          <input placeholder="Last name" />
        </div>
        <input placeholder="Email" />
        <input placeholder="Password" />
        <input placeholder="Repeat Password" />
        <input placeholder="Phone" />
        <select>
          <option>Gender</option>
          <option>Male</option>
          <option>Female</option>
        </select>
        <button className="btn">Create account</button>
        <p>Already have an account?</p>
        <Link to="/">Login</Link>
      </div>
    </div>
  );
}
