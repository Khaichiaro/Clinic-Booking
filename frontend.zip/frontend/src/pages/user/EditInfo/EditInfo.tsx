import './EditInfo.css';
import PatientLogo from "../../../assets/PatientLogo.svg";

export default function EditInfoPage() {
  return (
    <div className="edit-container">
      <header>
        <img src="/stethoscope-icon.svg" />
        <button className="logout">Logout</button>
      </header>
      <div className="edit-card">
        <img className="avatar" src={PatientLogo} />
        <h2>Edit information</h2>
        <div className="row">
          <input placeholder="First name" />
          <input placeholder="Last name" />
        </div>
        <input placeholder="Email" />
        <input placeholder="Old password" />
        <input placeholder="New password" />
        <input placeholder="Repeat new password" />
        <input placeholder="Phone" />
        <select>
          <option>Gender</option>
          <option>Male</option>
          <option>Female</option>
        </select>
        <button className="btn">Confirm</button>
      </div>
    </div>
  );
}
