import { useEffect, useState } from "react";
import { getUsers, createUser, updateUser, deleteUser, type User } from "../services/service";

export function useUsers() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  async function fetchUsers() {
    try {
      setLoading(true);
      const data = await getUsers();
      setUsers(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleCreate(user: User) {
    const newUser = await createUser(user);
    setUsers((prev) => [...prev, newUser]);
  }

  async function handleUpdate(id: number, user: Partial<User>) {
    const updated = await updateUser(id, user);
    setUsers((prev) => prev.map((u) => (u.id === id ? updated : u)));
  }

  async function handleDelete(id: number) {
    await deleteUser(id);
    setUsers((prev) => prev.filter((u) => u.id !== id));
  }

  return {
    users,
    loading,
    error,
    fetchUsers,
    createUser: handleCreate,
    updateUser: handleUpdate,
    deleteUser: handleDelete,
  };
}
