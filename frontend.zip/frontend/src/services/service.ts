const API_URL = "http://localhost:5000/api/users"; // เปลี่ยน URL หาก backend เปลี่ยน

export interface User {
  id?: number;
  first_name: string;
  last_name: string;
  password: string;
  email: string;
  phone_number: string;
  gender_id: number;
}

export interface Gender {
  id: number;
  gender: string;
}

// GET /api/users
export async function getUsers(): Promise<User[]> {
  const res = await fetch(API_URL);
  if (!res.ok) throw new Error("Failed to fetch users");
  return res.json();
}

// POST /api/users
export async function createUser(user: User): Promise<User> {
  const res = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(user),
  });
  if (!res.ok) throw new Error("Failed to create user");
  return res.json();
}

// PUT /api/users/:id
export async function updateUser(id: number, user: Partial<User>): Promise<User> {
  const res = await fetch(`${API_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(user),
  });
  if (!res.ok) throw new Error("Failed to update user");
  return res.json();
}

// DELETE /api/users/:id
export async function deleteUser(id: number): Promise<void> {
  const res = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to delete user");
}
