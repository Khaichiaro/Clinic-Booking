// src/services/authService.ts

export interface LoginRequest {
    email: string;
    password: string;
  }
  
  export async function loginUser(data: LoginRequest): Promise<boolean> {
    const res = await fetch('http://localhost:5000/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
  
    if (!res.ok) {
      throw new Error('Invalid email or password');
    }
  
    const json = await res.json();
    localStorage.setItem('user_id', json.id); // ✅ ใช้งาน json
  
    return true;
  }
  