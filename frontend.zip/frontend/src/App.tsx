//import React from "react";
import { BrowserRouter as Router, Routes, Route} from "react-router-dom";
import LoginPage from "./pages/user/login/Login";
import RegisterPage from "./pages/user/register/Register";
import PatientInfo from "./pages/user/patientInfo/PatientInfo";
import EditInfo from "./pages/user/EditInfo/EditInfo";
import HomePage from "./pages/user/home/Home";

// import AppointmentPage from "./pages/Appointment";
// import MyAppointmentsPage from "./pages/MyAppointments";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/home" element={<HomePage />} />
        <Route path="/patient" element={<PatientInfo />} />
        <Route path="/edit" element={<EditInfo />} />
      </Routes>
    </Router>
  );
}

export default App;
